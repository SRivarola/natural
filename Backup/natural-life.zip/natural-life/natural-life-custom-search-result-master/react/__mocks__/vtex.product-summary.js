import React from 'react'

export function ProductSummary(props) {
  return <div>{props.children}</div>
}
