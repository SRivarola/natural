export function useResponsiveValue(values) {
  return values.desktop
}
