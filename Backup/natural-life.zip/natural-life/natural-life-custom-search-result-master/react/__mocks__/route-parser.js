export default class RouteParser {
  reverse() {
    return ''
  }
}

export var __useDefault = true
