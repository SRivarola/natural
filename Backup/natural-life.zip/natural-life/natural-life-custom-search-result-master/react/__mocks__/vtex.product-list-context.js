const ProductListProvider = ({ children }) => children

export const useProductImpression = () => {}

export const ProductListContext = { ProductListProvider }
