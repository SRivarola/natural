import React from 'react'

export const IconFilter = () => <div>IconFilter</div>
export const IconCaret = () => <div>IconCaret</div>
export const IconGrid = () => <div>IconGrid</div>
export const IconInlineGrid = () => <div>IconInlineGrid</div>
export const IconSingleGrid = () => <div>IconSingleGrid</div>
