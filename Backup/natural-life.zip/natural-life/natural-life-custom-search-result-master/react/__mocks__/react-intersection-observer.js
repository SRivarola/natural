export const useInView = () => [null, false]
