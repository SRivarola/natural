// import { createContext } from 'react'

// const QueryContext = createContext({})

// export default QueryContext
