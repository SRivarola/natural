import FilterNavigator from './components/FilterNavigator/legacy/index'
export default FilterNavigator
