# VTEXIO-JUST-FOR-SPORT-CUSTOM-SEARCH-RESULT

Bloco customizado que permite a inserção de imagens no filtro de cor