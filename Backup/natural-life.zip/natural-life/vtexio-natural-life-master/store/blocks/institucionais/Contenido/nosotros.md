# ¿Quienes somos?

## Hace más de 30 años nos dedicamos al cuidado de las mascotas

###### Nuestra visión
Las mascotas son nuestra pasión. Trabajamos todos los días para mejorar su calidad de vida, como así también la relación con sus tutores mediante el traspaso de información útil y la recomendación de productos adecuados.

###### Nuestra misión 
Lograr que nuestra comunidad comparta la misma pasión que nosotros por las mascotas y, de esta forma, seguir fomentando el cuidado de las mismas. Continuar brindando la mejor atención por medio de personal capacitado para informar y cubrir las necesidades del cliente y su mascota con productos de primera calidad.