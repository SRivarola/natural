# Delivery

## Natural Life te ofrece un completo servicio de envíos.

Envío a domicilio y sin cargo en C.A.B.A. y G.B.A en compras mayores a $2900.-
Por compras menores a $2900, consultá costo de envío.
También podés retirar tu pedido SIN CARGO por nuestra red de sucursales. 

###### Envío en el día

Realizá tu pedido antes de las 12 hs. y recibilo en tu casa el mismo día. Válido para C.A.B.A y G.B.A.

Condiciones:

- De lunes a sábados realizando tu pedido de 0 a 12 hs., lo recibís el mismo día entre las 14 y 21 hs.
- De lunes a sábados realizando tu pedido entre las 12 y 24 hs., lo recibís al día siguiente.
- Los pedidos realizados los sábados a partir de las 12 hs y domingos se entregarán el día lunes.
- Días feriados no aplica.
- Luján, Campana, La Plata y Rosario quedan exceptuados.

###### Zonas de entrega

Consultar días y horarios según tu domicilio.
Resto del mapa consultar costos, días y horarios a confirmar según disponibilidad.

![Zona de Delivery](/arquivos/Delivery2.png)

Si tenés alguna duda, consulta, sugerencia o simplemente necesitás coordinar un envío o retiro de mercadería por alguna sucursal, podés contactarnos por los siguientes medios:
Horario de atención: de lunes a sábados de 9 a 20 hs.
Teléfono: [0810-999-6288 (Natural).](tel:08109996288)
Whatsapp: [+54 9 11 5984-5785.](https://wa.me/5491159845785)
También podés enviarnos un mail a:  ventas@natural-life.com.ar.