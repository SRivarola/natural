import CustomPrices from "./components/CustomPrices/CustomPrices"

export default CustomPrices