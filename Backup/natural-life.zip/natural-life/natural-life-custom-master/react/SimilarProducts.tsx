import SimilarProducts from './components/SimilarProducts'

export default SimilarProducts
