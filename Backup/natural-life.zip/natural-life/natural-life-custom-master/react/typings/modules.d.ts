declare module '@vtex/insane'
