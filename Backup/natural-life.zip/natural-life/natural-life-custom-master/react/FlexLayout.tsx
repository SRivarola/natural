import FlexLayout from './components/Layout/FlexLayout'

export default FlexLayout
