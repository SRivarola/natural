declare module '@vtex/insane'
