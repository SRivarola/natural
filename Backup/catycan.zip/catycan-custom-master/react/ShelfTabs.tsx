import ShelfTabs from "./components/ShelfTabs/ShelfTabs"

export default ShelfTabs