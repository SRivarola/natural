import CustomPriceProduct from './components/CustomPriceProduct/CustomPriceProduct'

export default CustomPriceProduct
