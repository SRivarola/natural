import SearchQuery from './components/SearchQuery'
export default SearchQuery
