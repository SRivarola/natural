declare module 'vtex.product-summary/ProductSummaryCustom'
