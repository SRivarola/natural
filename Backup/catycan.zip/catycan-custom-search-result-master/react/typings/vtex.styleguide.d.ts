declare module 'vtex.styleguide' {
  import { ComponentType } from 'react'

  export const Spinner: ComponentType<Record<string, unknown>>
}
