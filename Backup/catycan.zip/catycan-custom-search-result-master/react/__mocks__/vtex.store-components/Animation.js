import React from 'react'

const Animation = () => <div>Animation</div>

export default Animation
