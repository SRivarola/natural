export const useSearchPage = () => ({
  searchQuery: undefined,
})
