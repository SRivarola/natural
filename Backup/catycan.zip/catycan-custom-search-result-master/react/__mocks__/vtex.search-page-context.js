export const SearchPageContext = {
  useSearchPageState: jest.fn(),
}
