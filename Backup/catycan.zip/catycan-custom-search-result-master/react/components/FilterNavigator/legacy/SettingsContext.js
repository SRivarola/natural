// import { createContext } from 'react'

// const SettingsContext = createContext({})

// export default SettingsContext
