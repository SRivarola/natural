# Medios de pago

## Disponemos de diversas modalidades de pago habilitadas para garantizar tu comodidad. 

###### EFECTIVO 

- Realizá tu compra desde nuestro sitio web.
- Seleccioná el método de pago "Efectivo".
- Confirmá finalmente tu pedido.

###### TRANSFERENCIA BANCARIA

- Realizá tu compra desde nuestro sitio web.
- Seleccioná el método de pago: "Transferencia Bancaria".
- Realizá la transferencia con los datos que te indicamos al confirmar el pedido.

###### TARJETA DE CRÉDITO / DÉBITO

- Realizá tu compra desde nuestro sitio web.
- Seleccioná el método de pago: "Tarjeta de crédito / débito".
- Confirmá finalmente tu pedido.

###### MERCADO PAGO

- Realizá tu compra desde nuestro sitio web.
- Seleccioná el método de pago "Mercado Pago".
- Aprovechá las promociones vigentes con Tarjeta de Crédito: