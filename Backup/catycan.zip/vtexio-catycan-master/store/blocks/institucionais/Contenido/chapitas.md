# Chapitas al instante

Ahora grabar la chapita identificatoria de tu mascota, con el nombre y un teléfono, es muy fácil y lo hacemos al instante. Elegís el diseño de medalla que más te guste, se graba al instante y te la llevás en minutos. Ideal para identificar a tu mascota y evitar que se extravíe, fundamental todo el año pero indispensable para épocas de vacaciones.
Podés elegir entre una gran variedad de modelos y materiales.

## Chapitas identificatorias para perros

¿Has escuchado hablar de las chapitas para perro? ¡Seguro que sí! Son esos elementos que se incorporan a sus collares para que, si el animal se extravía, pueda ser devuelto de inmediato a su domicilio y al amor de su familia.

Si sos de los que aman llevar a caminar o de paseo al canino cada día, o bien, vivís en una zona sin tránsito por lo que lo dejás salir unas horas a la calle para que tenga contacto con otros animales del lugar y corra un poco, entonces adquirir una chapita para perro será la inversión perfecta dado que, en caso de que tu amada mascota se aleje y desoriente, quien lo encuentre podrá tomar contacto con vos para que puedas acudir en busca del animal.

En las chapitas identificatorias para perro podrás incluir: nombre del perro y datos de contacto de su familiar (teléfono y/o dirección). Es un elemento, a nuestro criterio, muy necesario y que no requiere de una gran inversión.

![Chapitas](/arquivos/chapitas.png)