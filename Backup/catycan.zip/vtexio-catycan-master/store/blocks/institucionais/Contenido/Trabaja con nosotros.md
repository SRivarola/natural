# Trabajá con nosotros

## catycan Life dedicada hace más de 25 años al cuidado de las mascotas.

###### Nuestras búsquedas activas

Médicos/as Veterinarios/as con formación comercial
Será su función la Atención al Cliente y desarrollar el consultorio médico apuntalando el crecimiento del negocio. Se orienta a la búsqueda a Profesionales graduado con experiencia comprobable en consultorios y experiencias comerciales. Seleccionaremos perfiles proactivos con alto nivel de compromiso con el proyecto y con ambición de crecimiento

Requisitos:

- Ambos sexos.
- 25 a 50 años (no excluyente)
- Matriculado en Provincia de Buenos Aires
- Experiencia en consulta clínica y venta de productos veterinarios/farmacia.
- Residir en las zonas OESTE, SUR de G.B.A. y CAMPANA
- Amplia disponibilidad horaria

Es una importante oportunidad para quienes busquen asumir grandes desafíos dentro de una organización líder. Se ofrece contratación efectiva, muy buen clima laboral, plan de carrera a mediano plazo.

- REFERENCIA: Ref. MV  (zona donde viven), ejemplo: Ref. MV (MERLO)